// api/server.js
import express from "express";
import cors from "cors";
import { pool } from "./db.js";

const app = express();
app.use(cors());
app.use(express.json());

// rota de teste de conexão
app.get("/ping-db", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT 1+1 AS result");
    res.json({ db: rows[0].result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// rota para listar alunos
app.get("/alunos", async (req, res) => {
  const [rows] = await pool.query("SELECT * FROM alunos");
  res.json(rows);
});

// rota para criar aluno
app.post("/alunos", async (req, res) => {
  const { codigo, nome, turma } = req.body;
  const [result] = await pool.query(
    "INSERT INTO alunos (codigo,nome,turma) VALUES (?,?,?)",
    [codigo, nome, turma]
  );
  res.json({ insertId: result.insertId });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`API rodando na porta ${PORT}`));